//
//  ViewController.swift
//  NHKList
//
//  Created by cmStudent on 2019/06/19.
//  Copyright © 2019 weng wei heng 19cm0107. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var listTableView: UITableView!
    var  program : ProgramList? = nil
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return program!.list.g1!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = listTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath) as! ListTableViewCell
        
        cell.setProgramList(program: program!.list.g1![indexPath.row])
        
        return cell
    }
    
    var selecrtDate: ProgramList?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        listTableView.register(UINib(nibName: "ListTableViewCell", bundle: nil), forCellReuseIdentifier: "listCell")
        
        listTableView.estimatedRowHeight = 10
        
        listTableView.rowHeight = UITableView.automaticDimension
        
        getProgramList()

    }

    
    func getProgramList(){
        
        let urlString: String = "https://jsondata.okiba.me/v1/json/fbQoM190619000801"
        
        guard let url : URL = URL(string: urlString)else { return }
        
        let semaphore = DispatchSemaphore(value: 0)
        
        
        
        let task = URLSession.shared.dataTask(with: url, completionHandler: {data, response, error in
            do{
                self.program = try JSONDecoder().decode(ProgramList.self,from: data!)
                semaphore.signal()
            } catch(let message){
                print("エラーが発生しました。")
                print(message)
                return
            }
        })
        
        task.resume()
        print("どっちが先に実行されるか、わからないよ")
        semaphore.wait()
        print("処理を待ったよ")
        
    }

}

