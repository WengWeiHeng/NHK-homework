//
//  ListTableViewCell.swift
//  NHKList
//
//  Created by cmStudent on 2019/06/19.
//  Copyright © 2019 weng wei heng 19cm0107. All rights reserved.
//

import UIKit

class ListTableViewCell: UITableViewCell {

    @IBOutlet weak var ProgramImage: UIImageView!
    @IBOutlet weak var ProgramName: UILabel!
    
    @IBOutlet weak var ProgramSubtitle: UILabel!
    
    @IBOutlet weak var StartTime: UILabel!
    
    @IBOutlet weak var EndTime: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func setProgramList(program : Program){
        self.ProgramName.text = program.title
        self.ProgramSubtitle.text = program.subtitle
        self.StartTime.text = program.start_time
        self.EndTime.text = program.end_time
    }
    
}
