//
//  ListCell.swift
//  NHKAppList
//
//  Created by Heng on 2019/12/27.
//  Copyright © 2019 Heng. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell{
    
    //MARK: - properties
    let programImage: UIImageView = {
        let imageView = UIImageView()
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        
        return imageView
    }()
    
    let programTitle: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 21)
        label.numberOfLines = 2
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.textColor = .mainDarkGray()
        
        return label
    }()
    
    let programSubtitle: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 15)
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.textColor = .mainDarkGray()
        
        return label
    }()
    
    let startTime: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = .mainLightGray()
        
        return label
    }()
    
    let endTime: UILabel = {
        let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 12)
        label.textColor = .mainLightGray()
        
        return label
    }()
    //MARK: - Init
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectionStyle = .none
        
        configureProgramList()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: - Helper Functions
    
    func configureProgramList(){
        addSubview(programTitle)
        programTitle.anchor(top: topAnchor, left: leftAnchor, bottom: nil, right: rightAnchor, paddingTop: 0, paddingLeft: 15, paddingBottom: 0, paddingRight: 15, width: 0, height: 0)
        
        addSubview(programSubtitle)
        programSubtitle.anchor(top: programTitle.bottomAnchor, left: programTitle.leftAnchor, bottom: nil, right: rightAnchor, paddingTop: 10, paddingLeft: 0, paddingBottom: 0, paddingRight: 15, width: 0, height: 0)
        
        addSubview(startTime)
        startTime.anchor(top: programSubtitle.bottomAnchor, left: programTitle.leftAnchor, bottom: nil, right: nil, paddingTop: 10, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 0)
        
        addSubview(endTime)
        endTime.anchor(top: startTime.bottomAnchor, left: programTitle.leftAnchor, bottom: nil, right: nil, paddingTop: 10, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 0)
    }
    
    func setProgramInfo(program: Program){
        programTitle.text = program.title
        programSubtitle.text = program.subtitle
        startTime.text = program.start_time
        endTime.text = program.end_time
    }
}
