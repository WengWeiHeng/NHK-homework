//
//  ProgramList.swift
//  NHKAppList
//
//  Created by Heng on 2019/12/27.
//  Copyright © 2019 Heng. All rights reserved.
//

import Foundation

struct ProgramList: Codable{
    var list: Service
}

struct Area: Codable{
    var id: String
    var name: String
}

struct Logo: Codable{
    var url: String
    var width: String
    var height: String
}

struct ServiceDetail: Codable{
    var id: String
    var name: String
    var logo_s: Logo
    var logo_m: Logo
    var logo_l: Logo
}

struct Program: Codable{
    var id: String
    var event_id: String
    var start_time: String
    var end_time: String
    var area: Area
    var service: ServiceDetail
    var title: String
    var subtitle: String
    var content: String
    var act: String
    var genres: [String]
}

struct Service: Codable{
    var g1: [Program]?
    var e1: [Program]?
    var r1: [Program]?
}

struct Extra: Codable{
    var ondemand_program: Link
    var ondemand_episode: Link
}

struct Link: Codable {
    var url: String
    var title: String
    var id: String
}
