//
//  ProgramController.swift
//  NHKAppList
//
//  Created by Heng on 2019/12/27.
//  Copyright © 2019 Heng. All rights reserved.
//

import UIKit

private let reuseIdentifier = "ListCell"

class ProgramController: UIViewController{
    
    //MARK: - properties
    var tableView: UITableView!
    var program: ProgramList? = nil
    var selectData: ProgramList?
    
    //MARK: - Init
    override func viewDidLoad() {
        super.viewDidLoad()
        configureViewItem()
    }
    
    //MARK: - Helper Function
    func configureViewItem(){
        configureTableView()
        getProgramInfo()
    }
    
    func configureTableView(){
        tableView = UITableView()
        //tableView.rowHeight = UITableView.automaticDimension
        tableView.rowHeight = 190
        print(tableView.rowHeight)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(ListCell.self, forCellReuseIdentifier: reuseIdentifier)
        tableView.separatorStyle = .none
        
        view.addSubview(tableView)
        tableView.anchor(top: view.topAnchor, left: view.leftAnchor, bottom: view.bottomAnchor, right: view.rightAnchor, paddingTop: 0, paddingLeft: 0, paddingBottom: 0, paddingRight: 0, width: 0, height: 0)
    }
    
    func getProgramInfo(){
        let urlString: String = "https://jsondata.okiba.me/v1/json/fbQoM190619000801"
        guard let url: URL = URL(string: urlString) else{ return }
        
        let semaphore = DispatchSemaphore(value: 0)
        let task = URLSession.shared.dataTask(with: url, completionHandler: { data, response, error in
            do{
                self.program = try JSONDecoder().decode(ProgramList.self, from: data!)
                semaphore.signal()
            } catch(let message){
                print("error..")
                print(message)
                return
            }
        })
        task.resume()
        semaphore.wait()
    }
}

extension ProgramController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return program!.list.g1!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! ListCell
        cell.setProgramInfo(program: program!.list.g1![indexPath.row])
        
        return cell
    }
    
    
}
